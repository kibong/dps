PHONE_NUMBER_START_TOKEN = "<|tel_start|>"
PHONE_NUMBER_END_TOKEN = "<|tel_end|>"

RRN_START_TOKEN = "<|rrn_start|>"
RRN_END_TOKEN = "<|rrn_end|>"

URL_START_TOKEN = "<|url_start|>"
URL_END_TOKEN = "<|url_end|>"

EMAIL_START_TOKEN = "<|email_start|>"
EMAIL_END_TOKEN = "<|email_end|>"

CARD_START_TOKEN = "<|crd_start|>"
CARD_END_TOKEN = "<|crd_end|>"

ACCOUNT_START_TOKEN = "<|acc_start|>"
ACCOUNT_END_TOKEN = "<|acc_end|>"

NAME_START_TOKEN = "<|name_start|>"
NAME_END_TOKEN = "<|name_end|>"

ORG_START_TOKEN = "<|org_start|>"
ORG_END_TOKEN = "<|org_end|>"


# Name of the colum that contains the document
DEFAULT_DOC_COLUMN = "text"
